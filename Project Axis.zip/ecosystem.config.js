module.exports = {
  apps: [{
    name: "axis-xmd",
    script: "./server.js",
    watch: false,
    autorestart: true,
    max_memory_restart: "800M",
    node_args: "--max-old-space-size=700",
    env: {
      NODE_ENV: "production"
    },
    error_file: "./logs/error.log",
    out_file:   "./logs/output.log",
    log_date_format: "YYYY-MM-DD HH:mm:ss",
    combine_logs: true,
    time: true,
    restart_delay: 5000,
    max_restarts: 10,
    min_uptime: "10s"
  }]
};