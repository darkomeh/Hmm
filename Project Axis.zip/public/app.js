// ============================================
// AXIS XMD — app.js
// For: MR Dark Omeh (@Mrdarkomeh)
// ============================================

let currentUser = null;
let audioContext = null;
let userHasInteracted = false;

// ============================================
// INIT
// ============================================
document.addEventListener('DOMContentLoaded', () => {
  spawnParticles();
  loadHeroStats();
  checkAuth();
});

// Audio interaction unlock
document.addEventListener('touchstart', () => {
  userHasInteracted = true;
  if (!audioContext) initAudio();
}, { once: true });
document.addEventListener('click', () => {
  userHasInteracted = true;
  if (!audioContext) initAudio();
}, { once: true });

// Enter key in login
document.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    const overlay = document.getElementById('loginOverlay');
    if (overlay && !overlay.classList.contains('hidden')) handleLogin();
  }
});

// ============================================
// BACKGROUND PARTICLES
// ============================================
function spawnParticles() {
  const container = document.getElementById('bgParticles');
  if (!container) return;
  for (let i = 0; i < 40; i++) {
    const p = document.createElement('div');
    p.className = 'bg-particle';
    p.style.left      = (Math.random() * 100) + 'vw';
    p.style.setProperty('--dur',   (4 + Math.random() * 6) + 's');
    p.style.setProperty('--delay', (Math.random() * 8) + 's');
    p.style.setProperty('--drift', (Math.random() * 80 - 40) + 'px');
    container.appendChild(p);
  }
}

// ============================================
// AUDIO
// ============================================
function initAudio() {
  try { audioContext = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) {}
}

function playClick() {
  if (!audioContext || !userHasInteracted) return;
  try {
    if (audioContext.state === 'suspended') audioContext.resume();
    const osc  = audioContext.createOscillator();
    const gain = audioContext.createGain();
    osc.connect(gain);
    gain.connect(audioContext.destination);
    osc.frequency.value = 500;
    osc.type = 'sine';
    gain.gain.setValueAtTime(0.035, audioContext.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 0.08);
    osc.start(audioContext.currentTime);
    osc.stop(audioContext.currentTime + 0.08);
  } catch (e) {}
}

document.addEventListener('click', (e) => {
  if (e.target.closest('button')) playClick();
});

// ============================================
// SLIDE MENU
// ============================================
function openSlideMenu() {
  document.getElementById('slideMenu').classList.add('open');
  document.getElementById('menuOverlay').classList.add('open');
  document.getElementById('menuBtn')?.classList.add('open');
}

function closeSlideMenu() {
  document.getElementById('slideMenu').classList.remove('open');
  document.getElementById('menuOverlay').classList.remove('open');
  document.getElementById('menuBtn')?.classList.remove('open');
}

// ============================================
// PANELS (Credits / Tutorial / Rules)
// ============================================
function openPanel(name) {
  closeSlideMenu();

  const overlay   = document.getElementById('panelOverlay');
  const credPanel = document.getElementById('creditsPanel');
  const tutPanel  = document.getElementById('tutorialPanel');
  const rulPanel  = document.getElementById('rulesPanel');

  // Hide all panels
  credPanel.classList.add('hidden');
  tutPanel.classList.add('hidden');
  rulPanel.classList.add('hidden');

  // Show correct panel
  const map = {
    credits:  credPanel,
    tutorial: tutPanel,
    rules:    rulPanel
  };
  if (map[name]) map[name].classList.remove('hidden');

  overlay.classList.remove('hidden');
  overlay.scrollTop = 0;
}

function closePanel() {
  document.getElementById('panelOverlay').classList.add('hidden');
}

// ============================================
// MASTER MENU
// ============================================
function toggleMasterMenu() {
  const menu    = document.getElementById('masterMenu');
  const overlay = document.getElementById('masterMenuOverlay');
  const btn     = document.getElementById('masterMenuBtn');
  const isOpen  = menu.classList.contains('open');

  if (isOpen) {
    menu.classList.remove('open');
    overlay.classList.add('hidden');
    btn?.classList.remove('open');
  } else {
    menu.classList.add('open');
    overlay.classList.remove('hidden');
    btn?.classList.add('open');
  }
}

function closeMasterMenu() {
  document.getElementById('masterMenu')?.classList.remove('open');
  document.getElementById('masterMenuOverlay')?.classList.add('hidden');
  document.getElementById('masterMenuBtn')?.classList.remove('open');
}

// ============================================
// MASTER SECTIONS
// ============================================
function showMasterSection(name) {
  document.querySelectorAll('.master-section').forEach(s => s.classList.remove('active'));
  const sec = document.getElementById(name + 'Section');
  if (sec) sec.classList.add('active');

  // Nav active state
  document.querySelectorAll('#masterMenu .sm-item').forEach(i => i.classList.remove('sm-active'));
  if (name === 'dashboard') document.getElementById('masterNavDash')?.classList.add('sm-active');
  if (name === 'pairBot')   document.getElementById('masterNavPair')?.classList.add('sm-active');

  if (name === 'dashboard') loadDashboard();
}

// ============================================
// AUTH
// ============================================
function showLoginForm() {
  document.getElementById('loginOverlay').classList.remove('hidden');
  setTimeout(() => document.getElementById('username')?.focus(), 50);
}

function hideLoginForm() {
  document.getElementById('loginOverlay').classList.add('hidden');
  document.getElementById('loginError').classList.add('hidden');
  document.getElementById('username').value = '';
  document.getElementById('password').value = '';
}

async function handleLogin() {
  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value;
  const errorEl  = document.getElementById('loginError');

  if (!username || !password) {
    errorEl.textContent = 'Enter username and password';
    errorEl.classList.remove('hidden');
    return;
  }

  try {
    const res  = await fetch('/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ username, password })
    });
    const data = await res.json();

    if (data.success) {
      currentUser = data.user;
      hideLoginForm();
      if (currentUser.role === 'master') showMasterScreen();
    } else {
      errorEl.textContent = data.error || 'Login failed';
      errorEl.classList.remove('hidden');
    }
  } catch {
    errorEl.textContent = 'Connection error. Try again.';
    errorEl.classList.remove('hidden');
  }
}

function showMasterScreen() {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById('masterScreen').classList.add('active');
  showMasterSection('dashboard');
}

async function logout() {
  try { await fetch('/auth/logout', { method: 'POST', credentials: 'include' }); } catch (e) {}
  currentUser = null;
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById('homeScreen').classList.add('active');
}

async function checkAuth() {
  try {
    const res  = await fetch('/auth/me', { credentials: 'include' });
    const data = await res.json();
    if (data.user) {
      currentUser = data.user;
      if (currentUser.role === 'master') showMasterScreen();
    }
  } catch (e) {}
}

// ============================================
// HERO STATS
// ============================================
async function loadHeroStats() {
  try {
    const res = await fetch('/analytics/summary', { credentials: 'include' });
    if (res.ok) {
      const data = await res.json();
      if (data.success) {
        const el = document.getElementById('heroActiveBots');
        if (el) el.textContent = data.stats.activeBots ?? '--';
      }
    }
  } catch (e) {}
}

// ============================================
// PAIRING — Home screen
// ============================================
async function doPair() {
  const phone   = document.getElementById('pairNumber').value.replace(/[^0-9]/g, '');
  const errorEl = document.getElementById('pairError');
  const btn     = document.getElementById('pairBtn');

  errorEl.classList.add('hidden');

  if (!phone || phone.length < 10) {
    errorEl.textContent = 'Enter a valid number (at least 10 digits)';
    errorEl.classList.remove('hidden');
    return;
  }

  btn.innerHTML = '<span class="btn-gen-icon">⏳</span><span>Connecting...</span>';
  btn.disabled  = true;

  try {
    const res  = await fetch('/api/pair', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phoneNumber: phone })
    });
    const data = await res.json();

    if (data.success && data.sessionId) {
      document.getElementById('pairCode').textContent = '....';
      document.getElementById('pairForm').classList.add('hidden');
      document.getElementById('pairResult').classList.remove('hidden');
      document.getElementById('pairStatus').textContent = 'Connecting to WhatsApp...';
      await pollForCode(data.sessionId, 'pairCode', 'pairStatus');
    } else {
      errorEl.textContent = data.error || 'Failed to start pairing. Try again.';
      errorEl.classList.remove('hidden');
    }
  } catch {
    errorEl.textContent = 'Connection error. Please try again.';
    errorEl.classList.remove('hidden');
  } finally {
    btn.innerHTML = '<span class="btn-gen-icon">⚡</span><span>Generate Pairing Code</span>';
    btn.disabled  = false;
  }
}

function resetPair() {
  document.getElementById('pairNumber').value = '';
  document.getElementById('pairForm').classList.remove('hidden');
  document.getElementById('pairResult').classList.add('hidden');
  document.getElementById('pairError').classList.add('hidden');
}

function copyPairCode() {
  const code = document.getElementById('pairCode').textContent;
  navigator.clipboard.writeText(code.replace(/-/g, '')).then(() => {
    const btn = event.target;
    btn.textContent = 'Copied!';
    setTimeout(() => btn.textContent = 'Copy', 2000);
  });
}

// ============================================
// PAIRING — Master panel
// ============================================
async function doMasterPair() {
  const phone   = document.getElementById('masterPairNumber').value.replace(/[^0-9]/g, '');
  const errorEl = document.getElementById('masterPairError');
  const btn     = document.getElementById('masterPairBtn');

  errorEl.classList.add('hidden');

  if (!phone || phone.length < 10) {
    errorEl.textContent = 'Enter a valid phone number';
    errorEl.classList.remove('hidden');
    return;
  }

  btn.innerHTML = '<span class="btn-gen-icon">⏳</span><span>Connecting...</span>';
  btn.disabled  = true;

  try {
    const res  = await fetch('/api/pair', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ phoneNumber: phone })
    });
    const data = await res.json();

    if (data.success && data.sessionId) {
      document.getElementById('masterPairCode').textContent = '....';
      document.getElementById('masterPairForm').classList.add('hidden');
      document.getElementById('masterPairResult').classList.remove('hidden');
      document.getElementById('masterPairStatus').textContent = 'Connecting to WhatsApp...';
      await pollForCode(data.sessionId, 'masterPairCode', 'masterPairStatus');
    } else {
      errorEl.textContent = data.error || 'Failed to start pairing.';
      errorEl.classList.remove('hidden');
    }
  } catch {
    errorEl.textContent = 'Connection error. Please try again.';
    errorEl.classList.remove('hidden');
  } finally {
    btn.innerHTML = '<span class="btn-gen-icon">⚡</span><span>Generate Pairing Code</span>';
    btn.disabled  = false;
  }
}

function resetMasterPair() {
  document.getElementById('masterPairNumber').value = '';
  document.getElementById('masterPairForm').classList.remove('hidden');
  document.getElementById('masterPairResult').classList.add('hidden');
  document.getElementById('masterPairError').classList.add('hidden');
}

function copyMasterCode() {
  const code = document.getElementById('masterPairCode').textContent;
  navigator.clipboard.writeText(code.replace(/-/g, '')).then(() => {
    const btn = event.target;
    btn.textContent = 'Copied!';
    setTimeout(() => btn.textContent = 'Copy', 2000);
  });
}

// ============================================
// POLL FOR CODE
// ============================================
async function pollForCode(sessionId, codeElId, statusElId, maxAttempts = 30, interval = 2000) {
  const codeEl   = document.getElementById(codeElId);
  const statusEl = document.getElementById(statusElId);

  for (let i = 0; i < maxAttempts; i++) {
    try {
      const res  = await fetch(`/api/pair/code/${sessionId}`);
      const data = await res.json();

      if (data.success) {
        if (data.status === 'failed') {
          if (statusEl) statusEl.textContent = '❌ ' + (data.error || 'Failed. Try again.');
          return;
        }
        if (data.code) {
          if (codeEl)   codeEl.textContent   = data.code;
          if (statusEl) statusEl.textContent = '✅ Code ready! Enter it in WhatsApp now.';
          return;
        }
        if (data.status === 'connected') {
          if (statusEl) statusEl.textContent = '✅ Bot connected!';
          return;
        }
        if (data.status === 'already_paired') {
          if (statusEl) statusEl.textContent = '✅ Already paired and active!';
          return;
        }
        if (statusEl) statusEl.textContent = `Waiting... (${data.status})`;
      }
    } catch (e) {}
    await sleep(interval);
  }
  if (statusEl) statusEl.textContent = '⏱ Timed out. Please try again.';
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ============================================
// DASHBOARD
// ============================================
async function loadDashboard() {
  try {
    const res  = await fetch('/analytics/summary', { credentials: 'include' });
    const data = await res.json();
    if (data.success) {
      animateCount('statVisitors',      data.stats.totalVisitors  || 0);
      animateCount('statActiveBots',    data.stats.activeBots     || 0);
      animateCount('statTotalPairings', data.stats.totalPairings  || 0);
      animateCount('statFailed',        data.stats.failedPairings || 0);
    }
  } catch (e) { console.error('Dashboard load failed:', e); }
}

function animateCount(elId, target) {
  const el = document.getElementById(elId);
  if (!el) return;
  let current   = 0;
  const step    = Math.ceil(target / 30) || 1;
  const timer   = setInterval(() => {
    current = Math.min(current + step, target);
    el.textContent = current;
    if (current >= target) clearInterval(timer);
  }, 40);
}

// ============================================
// ANALYTICS
// ============================================
async function trackVisit() {
  try {
    await fetch('/analytics/track', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ eventType: 'visit', eventData: {} })
    });
  } catch (e) {}
}
trackVisit();
