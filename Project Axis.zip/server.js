require('dotenv').config();

const { execSync, spawn } = require('child_process');
const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const bcrypt = require('bcryptjs');
const path = require('path');
const fs = require('fs-extra');
const os = require('os');

// ============================================
// BOT ENGINE — delegates all WhatsApp logic to axis/pair.js
// ============================================
let startpairing;

try {
  startpairing = require('./axis/pair');
  console.log('✅ axis/pair.js loaded — WhatsApp pairing active');
} catch (e) {
  console.log('⚠ axis/pair.js not found — pairing disabled:', e.message);
  startpairing = null;
}

const app = express();
const PORT = process.env.PORT || 3000;

// Sessions live in nexstore/pairing — same directory pair.js uses
const NEXSTORE_PAIRING_DIR = path.join(__dirname, 'nexstore', 'pairing');

if (!fs.existsSync(NEXSTORE_PAIRING_DIR)) {
  fs.mkdirSync(NEXSTORE_PAIRING_DIR, { recursive: true });
}

// ============================================
// NGROK TUNNEL
// ============================================
function writeNgrokConfig(token, domain, port) {
  const configContent = `version: 3

agent:
  authtoken: ${token}

endpoints:
  - name: main
    url: https://${domain}
    upstream:
      url: ${port}
`;
  const configDir = path.join(os.homedir(), '.config', 'ngrok');
  const configPath = path.join(configDir, 'ngrok.yml');

  if (!fs.existsSync(configDir)) {
    fs.mkdirSync(configDir, { recursive: true });
  }

  fs.writeFileSync(configPath, configContent, 'utf8');
  return configPath;
}

function printTunnelBanner(domain) {
  console.log(`
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║  ✅ NGROK PERMANENT TUNNEL CONNECTED!                     ║
║                                                           ║
║  🌐 https://${domain.padEnd(45)}║
║                                                           ║
║  ✅ Same link forever — never changes!                    ║
║  ✅ Full HTTPS — No security warnings!                    ║
║  ✅ No port number needed!                                ║
║  ✅ Works on any VPS you move to!                         ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝
  `);
}

let bannerPrinted = false;

function startNgrokTunnel() {
  try {
    const NGROK_TOKEN = process.env.NGROK_TOKEN;
    const NGROK_DOMAIN = process.env.NGROK_DOMAIN;

    if (!NGROK_TOKEN || !NGROK_DOMAIN) {
      console.log('⚠ NGROK_TOKEN or NGROK_DOMAIN not set in .env — tunnel disabled');
      return;
    }

    try { execSync('pkill -f ngrok', { stdio: 'ignore' }); } catch (e) {}
    execSync('sleep 2');

    if (!fs.existsSync('./ngrok')) {
      console.log('📥 Downloading ngrok...');
      execSync(
        'curl -L https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-linux-amd64.tgz -o ngrok.tgz && tar -xzf ngrok.tgz && chmod +x ngrok && rm ngrok.tgz',
        { stdio: 'inherit' }
      );
      console.log('✅ Ngrok downloaded!');
    }

    const configPath = writeNgrokConfig(NGROK_TOKEN, NGROK_DOMAIN, PORT);
    console.log(`📝 Ngrok config written: ${configPath}`);

    bannerPrinted = false;

    const tunnel = spawn('./ngrok', ['start', 'main', '--config', configPath]);

    tunnel.stdout.on('data', (data) => {
      const output = data.toString();
      console.log(output);
      if (!bannerPrinted && (output.includes(NGROK_DOMAIN) || output.includes('url='))) {
        bannerPrinted = true;
        printTunnelBanner(NGROK_DOMAIN);
      }
    });

    tunnel.stderr.on('data', (data) => {
      const output = data.toString();
      console.log(output);
      if (!bannerPrinted && (output.includes(NGROK_DOMAIN) || output.toLowerCase().includes('started tunnel'))) {
        bannerPrinted = true;
        printTunnelBanner(NGROK_DOMAIN);
      }
    });

    tunnel.on('close', (code) => {
      console.log(`⚠ Ngrok closed (code: ${code}) — Restarting in 8s...`);
      setTimeout(startNgrokTunnel, 8000);
    });

    tunnel.on('error', (err) => {
      console.error('❌ Ngrok error:', err.message);
      setTimeout(startNgrokTunnel, 10000);
    });

  } catch (err) {
    console.error('❌ Ngrok setup error:', err.message);
    console.log('⚠ Site still accessible via IP:PORT');
  }
}

startNgrokTunnel();

// ============================================
// PERSISTENT DATA STORAGE
// ============================================
const DATA_FILE = './data.json';

function loadData() {
  try {
    if (fs.existsSync(DATA_FILE)) {
      return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    }
  } catch { console.log('⚠ Could not read data.json'); }
  return null;
}

function saveData() {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify({ users }, null, 2));
  } catch (err) { console.error('⚠ Failed to save data:', err.message); }
}

const savedData = loadData();
let users = savedData?.users || [
  {
    id: 1,
    username: 'admin',
    password: bcrypt.hashSync(process.env.ADMIN_PASSWORD || 'admin123', 10),
    role: 'master',
    expiration_date: '2099-12-31'
  }
];

// ============================================
// MIDDLEWARE
// ============================================
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(session({
  secret: process.env.SESSION_SECRET || 'crittix-domain-secret-2026',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false, httpOnly: true, maxAge: 24 * 60 * 60 * 1000 }
}));
app.use(express.static(path.join(__dirname, 'public')));

// ============================================
// ACTIVE BOTS & SESSION TRACKING
// ============================================
const activeBots = new Map();
const pairingSessions = new Map();

const analytics = {
  totalVisitors: 0,
  totalPairings: 0,
  failedPairings: 0,
  events: []
};

// ============================================
// AUTH MIDDLEWARE
// ============================================
const requireAuth = (req, res, next) => {
  if (req.session.user) return next();
  res.status(401).json({ success: false, error: 'Unauthorized' });
};

const requireMaster = (req, res, next) => {
  if (req.session.user?.role === 'master') return next();
  res.status(403).json({ success: false, error: 'Forbidden' });
};

// ============================================
// WEB BOT INSTANCE — bridges server.js to axis/pair.js
//
// pair.js owns all Baileys logic (socket creation, creds,
// reconnection, case.js routing). We just hand it callbacks
// so the frontend gets the pairing code and status updates.
// ============================================
async function startWebBotInstance(phoneNumber, sessionId) {
  if (!startpairing) {
    // Mock mode — simulate a code for testing without Baileys
    setTimeout(() => {
      const n1 = Math.floor(1000 + Math.random() * 9000);
      const n2 = Math.floor(1000 + Math.random() * 9000);
      const s = pairingSessions.get(sessionId);
      if (s) {
        s.code   = `${n1}-${n2}`;
        s.status = 'code_ready';
        pairingSessions.set(sessionId, s);
      }
    }, 2000);
    return;
  }

  // pair.js expects JID format for its tracker map
  const nexusDevNumber = phoneNumber + '@s.whatsapp.net';

  const webCallbacks = {

    onCode: (code) => {
      const s = pairingSessions.get(sessionId);
      if (s) {
        s.code   = code;
        s.status = 'code_ready';
        pairingSessions.set(sessionId, s);
      }
      analytics.totalPairings++;
      console.log(`📲 Web pairing code for ${phoneNumber}: ${code}`);
    },

    onConnect: (sock) => {
      activeBots.set(phoneNumber, { sock, phoneNumber, startTime: Date.now(), sessionId });
      const s = pairingSessions.get(sessionId);
      if (s) {
        s.status = 'connected';
        pairingSessions.set(sessionId, s);
      }
      console.log(`✅ Web bot connected: ${phoneNumber}`);
    },

    onDisconnect: () => {
      activeBots.delete(phoneNumber);
    }

  };

  try {
    await startpairing(nexusDevNumber, webCallbacks);
  } catch (err) {
    analytics.failedPairings++;
    const s = pairingSessions.get(sessionId);
    if (s) {
      s.status = 'failed';
      s.error  = err.message;
      pairingSessions.set(sessionId, s);
    }
    throw err;
  }
}

// ============================================
// AUTH ROUTES
// ============================================
app.post('/auth/login', async (req, res) => {
  const { username, password } = req.body;
  const user = users.find(u => u.username === username);
  if (!user) return res.json({ success: false, error: 'Invalid credentials' });
  const validPassword = await bcrypt.compare(password, user.password);
  if (!validPassword) return res.json({ success: false, error: 'Invalid credentials' });
  req.session.user = { id: user.id, username: user.username, role: user.role, expirationDate: user.expiration_date };
  res.json({ success: true, user: req.session.user });
});

app.post('/auth/logout', (req, res) => { req.session.destroy(); res.json({ success: true }); });

app.get('/auth/me', (req, res) => { res.json({ user: req.session.user || null }); });

// ============================================
// PAIRING ROUTES
// ============================================
app.post('/api/pair', async (req, res) => {
  const { phoneNumber } = req.body;
  if (!phoneNumber || phoneNumber.replace(/[^0-9]/g, '').length < 10) {
    return res.json({ success: false, error: 'Invalid phone number' });
  }
  const cleanPhone = phoneNumber.replace(/[^0-9]/g, '');
  const sessionId = `web-${cleanPhone}-${Date.now()}`;
  pairingSessions.set(sessionId, { phoneNumber: cleanPhone, status: 'pending', code: null, timestamp: Date.now() });
  try {
    await startWebBotInstance(cleanPhone, sessionId);
    res.json({ success: true, sessionId });
  } catch (err) {
    analytics.failedPairings++;
    pairingSessions.delete(sessionId);
    res.json({ success: false, error: err.message || 'Failed to start pairing' });
  }
});

app.get('/api/pair/code/:sessionId', (req, res) => {
  const s = pairingSessions.get(req.params.sessionId);
  if (!s) return res.json({ success: false, error: 'Session not found' });
  res.json({ success: true, code: s.code || null, status: s.status, error: s.error || null });
});

app.post('/api/disconnect', requireAuth, async (req, res) => {
  const cleanPhone = req.body.phoneNumber?.replace(/[^0-9]/g, '');
  const bot = activeBots.get(cleanPhone);
  if (!bot) return res.json({ success: false, error: 'Bot not found' });
  try {
    bot.sock.ev.removeAllListeners();
    bot.sock.end(undefined);
    activeBots.delete(cleanPhone);

    // Clean session from nexstore/pairing
    const jid = cleanPhone + '@s.whatsapp.net';
    const sessionPath = path.join(NEXSTORE_PAIRING_DIR, jid);
    if (fs.existsSync(sessionPath)) fs.rmdirSync(sessionPath, { recursive: true });

    res.json({ success: true });
  } catch (err) { res.json({ success: false, error: err.message }); }
});

// ============================================
// BOT STATUS ROUTES
// ============================================
app.get('/api/bots/active', requireMaster, (req, res) => {
  const bots = Array.from(activeBots.entries()).map(([phone, bot]) => ({
    phoneNumber: phone,
    uptime: Math.floor((Date.now() - bot.startTime) / 1000),
    startTime: bot.startTime
  }));
  res.json({ success: true, bots, count: bots.length });
});

// ============================================
// USER MANAGEMENT
// ============================================
app.get('/api/users', requireMaster, (req, res) => {
  const userList = users.filter(u => u.role !== 'master').map(({ password, ...u }) => u);
  res.json({ success: true, users: userList });
});

app.post('/api/users', requireMaster, async (req, res) => {
  const { username, password, expirationDate } = req.body;
  if (!username || !password || !expirationDate) return res.json({ success: false, error: 'Missing required fields' });
  if (users.find(u => u.username === username)) return res.json({ success: false, error: 'Username already exists' });
  const newUser = { id: users.length + 1, username, password: await bcrypt.hash(password, 10), role: 'premium', expiration_date: expirationDate };
  users.push(newUser);
  saveData();
  res.json({ success: true, user: { id: newUser.id, username: newUser.username } });
});

app.delete('/api/users/:id', requireMaster, (req, res) => {
  const index = users.findIndex(u => u.id === parseInt(req.params.id));
  if (index === -1) return res.json({ success: false, error: 'User not found' });
  if (users[index].role === 'master') return res.json({ success: false, error: 'Cannot delete master' });
  users.splice(index, 1);
  saveData();
  res.json({ success: true });
});

// ============================================
// ANALYTICS
// ============================================
app.get('/analytics/summary', requireMaster, (req, res) => {
  res.json({ success: true, stats: {
    totalVisitors:  analytics.totalVisitors,
    activeBots:     activeBots.size,
    totalPairings:  analytics.totalPairings,
    failedPairings: analytics.failedPairings
  }});
});

app.post('/analytics/track', (req, res) => {
  const { eventType, eventData } = req.body;
  analytics.events.push({ type: eventType, data: eventData, timestamp: Date.now() });
  if (eventType === 'visit') analytics.totalVisitors++;
  res.json({ success: true });
});

// ============================================
// SESSION RESTORATION
// Scans nexstore/pairing/ for existing <number>@s.whatsapp.net
// folders and reconnects them on server startup.
// pair.js handles the actual socket reconnection internally —
// we just trigger it with no web callbacks (no code needed,
// session is already authenticated).
// ============================================
async function restoreWebSessions() {
  if (!startpairing) return;

  try {
    if (!fs.existsSync(NEXSTORE_PAIRING_DIR)) return;

    const folders = fs.readdirSync(NEXSTORE_PAIRING_DIR, { withFileTypes: true })
      .filter(d => d.isDirectory() && d.name.endsWith('@s.whatsapp.net'))
      .map(d => d.name);

    console.log(`📂 Restoring ${folders.length} existing WhatsApp session(s)...`);

    for (const jid of folders) {
      const credsPath = path.join(NEXSTORE_PAIRING_DIR, jid, 'creds.json');
      if (!fs.existsSync(credsPath)) continue;

      const cleanPhone = jid.replace('@s.whatsapp.net', '');

      if (activeBots.has(cleanPhone)) continue;

      try {
        // No web callbacks for restore — pair.js reconnects silently
        // and hooks case.js as normal once connected
        await startpairing(jid, {
          onConnect: (sock) => {
            activeBots.set(cleanPhone, { sock, phoneNumber: cleanPhone, startTime: Date.now(), sessionId: `restore-${cleanPhone}` });
            console.log(`✅ Restored session: ${cleanPhone}`);
          },
          onDisconnect: () => {
            activeBots.delete(cleanPhone);
          }
        });

        await new Promise(r => setTimeout(r, 2000));
      } catch (e) {
        console.error(`❌ Failed to restore ${cleanPhone}:`, e.message);
      }
    }
  } catch (e) {
    console.error('Session restore error:', e.message);
  }
}

// Clean up stale pairing sessions every 5 minutes
setInterval(() => {
  const now = Date.now();
  for (const [id, s] of pairingSessions.entries()) {
    if (now - s.timestamp > 10 * 60 * 1000) pairingSessions.delete(id);
  }
}, 5 * 60 * 1000);

// ============================================
// SERVE FRONTEND
// ============================================
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ============================================
// DUCKDNS AUTO-UPDATE
// ============================================
async function updateDuckDNS(publicIP) {
  const DUCK_TOKEN  = process.env.DUCKDNS_TOKEN;
  const DUCK_DOMAIN = process.env.DUCKDNS_DOMAIN || 'crittixdomain';
  if (!DUCK_TOKEN) {
    console.log('⚠ DUCKDNS_TOKEN not set in .env — skipping DuckDNS update');
    return;
  }
  try {
    const url    = `https://www.duckdns.org/update?domains=${DUCK_DOMAIN}&token=${DUCK_TOKEN}&ip=${publicIP}`;
    const result = execSync(`curl -s "${url}"`).toString().trim();
    if (result === 'OK') {
      console.log(`
╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║  🦆 DUCKDNS AUTO-UPDATED!                                    ║
║                                                               ║
║  🌐 YOUR PERMANENT DOMAIN:                                   ║
║  http://${DUCK_DOMAIN}.duckdns.org:${PORT}                        ║
║                                                               ║
║  ✅ Domain always points to this VPS automatically!          ║
║  ✅ Change VPS anytime — domain updates itself on startup!   ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
      `);
    } else {
      console.log(`⚠ DuckDNS update response: ${result}`);
    }
  } catch (err) {
    console.error('❌ DuckDNS update error:', err.message);
  }
}

// ============================================
// START SERVER
// ============================================
app.listen(PORT, '0.0.0.0', async () => {
  let publicIP = 'unknown';
  try {
    publicIP = execSync('curl -s ifconfig.me', { timeout: 5000 }).toString().trim();
  } catch (e) {
    try { publicIP = execSync('curl -s api.ipify.org', { timeout: 5000 }).toString().trim(); } catch (e2) {}
  }

  console.log(`
╔═══════════════════════════════════════════╗
║                                           ║
║      ⚡  AXIS XMD  —  CRITTIX DOMAIN ⚡   ║
║                                           ║
║  Local:   http://localhost:${PORT}           ║
║  Public IP: ${publicIP.padEnd(30)}║
║                                           ║
║  🌐 Ngrok tunnel starting...              ║
║  🦆 DuckDNS auto-updating...              ║
║                                           ║
║  Created by: 𝐋𝐎𝐑𝐃♰𝔻𝐄𝐕𝐈𝐍𝐄 𓄿              ║
║  Bot: Λ𝗫𝗜𝗦 𝗫𝗠𝗗 — axis/pair.js             ║
║                                           ║
╚═══════════════════════════════════════════╝
  `);

  await updateDuckDNS(publicIP);
  await restoreWebSessions();
});

module.exports = { activeBots, analytics };