module.exports = {
  BOT_TOKEN: '8430575436:AAHForUyGcXoRPNyJYrbUPHzkAq5xOIGgQg',  
  startupPassword: '1'
};